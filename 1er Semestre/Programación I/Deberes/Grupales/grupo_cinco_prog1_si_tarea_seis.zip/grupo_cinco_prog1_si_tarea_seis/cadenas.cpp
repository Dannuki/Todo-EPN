#include <iostream>
#include <string>
#include <algorithm> // Incluido por si alguna funcion necesitara min/max, aunque no es directamente usada en estos ejemplos sencillos.

// Cadena base que se modificara o usara en los ejemplos
std::string cadena_ejemplo_base = "FIS la mejor facultad de la Poli";

// 1. length()
void ejemplo_length() {
    std::cout << "--- Demostracion de length() ---" << std::endl;
    std::string str = cadena_ejemplo_base;
    std::cout << "Cadena: \"" << str << "\"" << std::endl;
    std::cout << "Longitud: " << str.length() << std::endl;
    std::cout << std::endl;
}

// 2. size()
void ejemplo_size() {
    std::cout << "--- Demostracion de size() ---" << std::endl;
    std::string str = cadena_ejemplo_base;
    std::cout << "Cadena: \"" << str << "\"" << std::endl;
    std::cout << "Tamano: " << str.size() << std::endl;
    std::cout << std::endl;
}

// 3. append()
void ejemplo_append() {
    std::cout << "--- Demostracion de append() ---" << std::endl;
    std::string str = cadena_ejemplo_base;
    std::string anadir = " en Ecuador.";
    std::cout << "Cadena original: \"" << str << "\"" << std::endl;
    str.append(anadir);
    std::cout << "Despues de append(\" en Ecuador.\"): \"" << str << "\"" << std::endl;
    std::cout << std::endl;
}

// 4. find()
void ejemplo_find() {
    std::cout << "--- Demostracion de find() ---" << std::endl;
    std::string str = cadena_ejemplo_base;
    std::cout << "Cadena: \"" << str << "\"" << std::endl;
    size_t pos_facultad = str.find("facultad");
    if (pos_facultad != std::string::npos) {
        std::cout << "Posicion de 'facultad': " << pos_facultad << std::endl;
    } else {
        std::cout << "'facultad' no encontrado." << std::endl;
    }
    size_t pos_no_existe = str.find("ingenieria");
    if (pos_no_existe == std::string::npos) {
        std::cout << "'ingenieria' no encontrado." << std::endl;
    }
    std::cout << std::endl;
}

// 5. substr()
void ejemplo_substr() {
    std::cout << "--- Demostracion de substr() ---" << std::endl;
    std::string str = cadena_ejemplo_base;
    std::cout << "Cadena: \"" << str << "\"" << std::endl;
    std::string sub1 = str.substr(0, 3); // "FIS"
    std::cout << "substr(0, 3): \"" << sub1 << "\"" << std::endl;
    std::string sub2 = str.substr(7); // "mejor facultad de la Poli"
    std::cout << "substr(7): \"" << sub2 << "\"" << std::endl;
    std::cout << std::endl;
}

// 6. replace()
void ejemplo_replace() {
    std::cout << "--- Demostracion de replace() ---" << std::endl;
    std::string str = cadena_ejemplo_base;
    std::cout << "Cadena original: \"" << str << "\"" << std::endl;
    str.replace(7, 6, "gran"); // Reemplaza "mejor " por "gran "
    std::cout << "Despues de replace(7, 6, \"gran \"): \"" << str << "\"" << std::endl;
    std::cout << std::endl;
}

// 7. at()
void ejemplo_at() {
    std::cout << "--- Demostracion de at() ---" << std::endl;
    std::string str = cadena_ejemplo_base;
    std::cout << "Cadena: \"" << str << "\"" << std::endl;
    std::cout << "Caracter en posicion 0: " << str.at(0) << std::endl; // 'F'
    std::cout << "Caracter en posicion 4: " << str.at(4) << std::endl; // 'a'

    try {
        std::cout << "Intentando acceder a posicion 100 (fuera de limites): ";
        std::cout << str.at(100) << std::endl;
    } catch (const std::out_of_range& e) {
        std::cout << "Error: " << e.what() << std::endl;
    }
    std::cout << std::endl;
}

// 8. empty()
void ejemplo_empty() {
    std::cout << "--- Demostracion de empty() ---" << std::endl;
    std::string str_vacia = "";
    std::string str_no_vacia = cadena_ejemplo_base;

    std::cout << "Cadena vacia: \"" << str_vacia << "\"" << std::endl;
    std::cout << "Esta vacia?: " << (str_vacia.empty() ? "Si" : "No") << std::endl;

    std::cout << "Cadena no vacia: \"" << str_no_vacia << "\"" << std::endl;
    std::cout << "Esta vacia?: " << (str_no_vacia.empty() ? "Si" : "No") << std::endl;
    std::cout << std::endl;
}

// 9. clear()
void ejemplo_clear() {
    std::cout << "--- Demostracion de clear() ---" << std::endl;
    std::string str = cadena_ejemplo_base;
    std::cout << "Cadena antes de clear(): \"" << str << "\"" << std::endl;
    std::cout << "Longitud antes de clear(): " << str.length() << std::endl;
    str.clear();
    std::cout << "Cadena despues de clear(): \"" << str << "\"" << std::endl;
    std::cout << "Longitud despues de clear(): " << str.length() << std::endl;
    std::cout << std::endl;
}

// 10. compare()
void ejemplo_compare() {
    std::cout << "--- Demostracion de compare() ---" << std::endl;
    std::string s1 = "manzana";
    std::string s2 = "banana";
    std::string s3 = "manzana";
    std::string s4 = "manz";

    std::cout << "Comparando \"" << s1 << "\" con \"" << s2 << "\": " << s1.compare(s2) << " ( > 0 si s1 es mayor)" << std::endl;
    std::cout << "Comparando \"" << s1 << "\" con \"" << s3 << "\": " << s1.compare(s3) << " ( = 0 si son iguales)" << std::endl;
    std::cout << "Comparando \"" << s1 << "\" con \"" << s4 << "\": " << s1.compare(0, s4.length(), s4) << " ( = 0 si son iguales)" << std::endl;
    std::cout << std::endl;
}

// 11. erase()
void ejemplo_erase() {
    std::cout << "--- Demostracion de erase() ---" << std::endl;
    std::string str = cadena_ejemplo_base;
    std::cout << "Cadena original: \"" << str << "\"" << std::endl;
    str.erase(0, 4); // Borra "FIS "
    std::cout << "Despues de erase(0, 4): \"" << str << "\"" << std::endl; // "la mejor facultad de la Poli"
    str.erase(str.find("Poli")); // Borra "Poli" y lo que sigue (si hay)
    std::cout << "Despues de erase(pos 'Poli'): \"" << str << "\"" << std::endl; // "la mejor facultad de la "
    std::cout << std::endl;
}

int main() {
    std::cout << "--- PROGRAMA DE MANEJO DE CADENAS EN C++ ---" << std::endl;
    std::cout << std::endl;

    ejemplo_length();
    ejemplo_size();
    ejemplo_append();
    ejemplo_find();
    ejemplo_substr();
    ejemplo_replace();
    ejemplo_at();
    ejemplo_empty();
    ejemplo_clear();
    ejemplo_compare();
    ejemplo_erase();

    return 0;
}