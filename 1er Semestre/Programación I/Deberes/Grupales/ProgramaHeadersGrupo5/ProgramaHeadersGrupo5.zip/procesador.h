#ifndef procesador_h
#define procesador_h

#include "operaciones.h"

class Procesador {
  public:
  int procesarSuma (int num1, int num2);
};

#endif