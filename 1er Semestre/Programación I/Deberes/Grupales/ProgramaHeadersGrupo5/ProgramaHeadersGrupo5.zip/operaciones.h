#ifndef operaciones_h
#define operaciones_h

int sumar (int num1, int num2);

#endif