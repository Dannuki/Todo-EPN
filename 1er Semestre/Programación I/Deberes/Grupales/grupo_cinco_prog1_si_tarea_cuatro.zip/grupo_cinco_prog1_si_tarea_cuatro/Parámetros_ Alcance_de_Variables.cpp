#include <iostream>
#include <string>
#include <vector>
using namespace std;

// Variables Globales
int totalVisitantes = 0;
int maxCapacidad = 100;
float ingresoTotal = 0.0f;

// Funciones con Parámetros por Valor
void calcularIngresosTuristas(float precioEntrada, int numVisitantes) {
    float ingreso = precioEntrada * numVisitantes;
    cout << "Ingresos generados: " << ingreso << " USD" << endl;
    //Modifica las variables globales
    ingresoTotal += ingreso;
    totalVisitantes += numVisitantes;
}

void generarReporteAtractivo(string nombreAtractivo, int visitantes, float ingresos, float rating, bool capacidadOK) {
    cout << "\nReporte de atractivo turístico: " << endl;
    cout << "  Visitantes: " << visitantes << " visitantes" << endl;
    cout << "  Ingresos: " << ingresos << " USD" << endl;
    cout << "  Rating promedio: " << rating << " puntos" << endl;
    cout << "  Capacidad " << (capacidadOK ? "OK" : "Excedida") << endl;
}

int calcularPromedioValoraciones(int sumaValoraciones, int numValoraciones) {
    int promedioValoraciones = 0;
    if (numValoraciones > 0) {
        promedioValoraciones = sumaValoraciones / numValoraciones;
    }
    cout << "Promedio de valoraciones: " << promedioValoraciones << " puntos" << endl;
    return promedioValoraciones;
}

float aplicarDescuentoEntrada(float precioOriginal, float porcentajeDescuento) {
    float descuento = precioOriginal * porcentajeDescuento;
    float precioConDescuento = precioOriginal - descuento;
    cout << "Precio con descuento: " << precioConDescuento << " USD" << endl;
    return precioConDescuento;
}

bool verificarLimiteCapacidad(int visitantesActuales, int limiteCapacidad) {
    bool dentroCapacidad = (visitantesActuales <= limiteCapacidad);
    cout << "Estado de capacidad (1=OK): " << dentroCapacidad << endl;
    return dentroCapacidad;
}

// Funciones con Parámetros por Referencia o Sin Parámetros
void registrarNuevoVisitante(int& visitantesLocal) {
    visitantesLocal++;
    totalVisitantes++;
    cout << "Visitante agregado. Visitantes locales: " << visitantesLocal << " visitantes" << endl;
}

void actualizarValoracionAtractivo(float& rating, int nuevaCalificacion) {
    rating = (rating + nuevaCalificacion) / 2.0f;
    cout << "Rating actualizado: " << rating << " puntos" << endl;
}

void registrarIngresoLocal(float& ingresoLocal, float precioEntrada) {
    ingresoLocal += precioEntrada;
    ingresoTotal += precioEntrada;
    cout << "Tras registrar Ingreso Local (por referencia), ingreso Quilotoa: " << ingresoLocal << " USD" << endl;
}

void reiniciarEstadisticas() {
    totalVisitantes = 0;
    ingresoTotal = 0.0f;
    cout << "Contadores reiniciados" << endl;
    cout << "Tras reiniciar, Total visitantes: " << totalVisitantes << " visitantes, Ingreso total: " << ingresoTotal << " USD" << endl;
}

void mostrarEstadisticas() {
    cout << "Resumen: Total visitantes = " << totalVisitantes << " visitantes, Ingreso total = " << ingresoTotal << " USD" << endl;
}

// Función Principal (main)
int main() {
    
    string atractivoTuristico = "Laguna Quilotoa";
    cout<<"-------------------------------------------------\n";
    cout << "Gestion de Atractivo Turistico: " << atractivoTuristico << endl;

    // Variables Locales (main, por referencia)
    int visitantesQuilotoa = 50;
    float ingresoQuilotoa = 0.0f;
    float ratingQuilotoa = 4.0f;

    // Variables Locales (main, por valor)
    int sumaValoraciones = 8;
    int numValoraciones = 2;
    float precioOriginal = 5.0f;

    // Demostración de Funciones y Variables
    calcularIngresosTuristas(precioOriginal, visitantesQuilotoa);
    cout << "Tras calcular ingresos turistas (por valor), ingreso Quilotoa: " << ingresoQuilotoa << " USD" << endl;

    registrarIngresoLocal(ingresoQuilotoa, precioOriginal);

     int nuevaValoracion = 3;
        cout << "Nueva valoracion en bloque: " << nuevaValoracion << " puntos" << endl;

    {
        int nuevaValoracion = 5;
        actualizarValoracionAtractivo(ratingQuilotoa, nuevaValoracion);
    }

    registrarNuevoVisitante(visitantesQuilotoa);
    cout << "Tras registrar nuevo visitante, visitantes Quilotoa: " << visitantesQuilotoa << " visitantes" << endl;

    calcularPromedioValoraciones(sumaValoraciones, numValoraciones);

    bool capacidadActualOK = false;
    {
        int estado = 1;
        capacidadActualOK = verificarLimiteCapacidad(visitantesQuilotoa, maxCapacidad);
        if (estado == 1) {
            // Alguna lógica basada en el estado
        }
    }

    generarReporteAtractivo(atractivoTuristico, visitantesQuilotoa, ingresoQuilotoa, ratingQuilotoa, capacidadActualOK);

    aplicarDescuentoEntrada(precioOriginal, 0.1f);

    cout << "Globales - Total visitantes: " << totalVisitantes << " visitantes, Ingreso total: " << ingresoTotal << " USD" << endl;

    reiniciarEstadisticas();

    mostrarEstadisticas();
   
    cout<<"---------------------------------------------------------\n";
    return 0;
}