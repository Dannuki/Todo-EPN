#ifndef OPERACIONES_H
#define OPERACIONES_H

#include "operador.h" 

void calcularCostoTour();
void gestionarReservaActividad();
void analizarDatosTuristicos();
void mostrarHistorialReservas();
void salirPrograma();

#endif // OPERACIONES_H