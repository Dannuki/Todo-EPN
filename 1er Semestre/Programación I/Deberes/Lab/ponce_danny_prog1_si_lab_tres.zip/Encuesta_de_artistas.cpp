#include <iostream>
#include <string>
#include <cctype>   // Para tolower el cual convierte mayusculas en minusculas
#include <limits>   // Para std::numeric_limits

using namespace std;

// Definición del enum para los géneros musicales 
enum GeneroMusical {
    Ninguno = 0,
    Pop = 1,
    Cumbia = 2,
    Salsa = 3,
    Rock = 4,
    Reggaeton = 5,
    Otro = 6
};

const int MAXIMO_ARTISTAS = 20; // Límite de artistas 

void inicializarArtistas(string nombres[], GeneroMusical generos[], int votos[], int& numero_de_artistas);
bool esNombreValido(const string& nombre, const string nombres[], int numero_de_artistas);
void registrarArtista(string nombres[], GeneroMusical generos[], int votos[], int& numero_de_artistas); // 
void registrarVoto(const string nombres[], int votos[], int numero_de_artistas); // 
void mostrarEstadisticas(const string nombres[], const GeneroMusical generos[], const int votos[], int numero_de_artistas); // 

// Función para inicializar artistas predefinidos 
void inicializarArtistas(string nombres[], GeneroMusical generos[], int votos[], int& numero_de_artistas){
    // Usar índices del 0 al 4 para los 5 artistas predefinidos 
    nombres[0] = "Bad Bunny";
    generos[0] = Reggaeton;
    votos[0] = 0;

    nombres[1] = "Karol G";
    generos[1] = Reggaeton;
    votos[1] = 0;

    nombres[2] = "Shakira";
    generos[2] = Pop;
    votos[2] = 0;

    nombres[3] = "Juanes";
    generos[3] = Rock;
    votos[3] = 0;

    nombres[4] = "Marc Anthony";
    generos[4] = Salsa;
    votos[4] = 0;

    numero_de_artistas = 5; // Establece el número inicial de artistas 
}

// Función para validar el nombre de un artista 
bool esNombreValido(const string& nombre, const string nombres[], int numero_de_artistas){
    // Valida si el nombre está vacío 
    if(nombre.empty()){
        cout << "Debe ingresar un nombre." << endl;
        return false;
    }

    // Convierte el nombre ingresado a minúsculas para comparación 
    string nombre_artistas_minusculas = "";
    for(char a : nombre){
        nombre_artistas_minusculas += tolower(a);
    }

    // Compara con los nombres existentes (ignorando mayúsculas/minúsculas) 
    for(int i = 0; i < numero_de_artistas; ++i){
        string nombre_artista_predefinido_minusculas = "";
        for(char a : nombres[i]){
            nombre_artista_predefinido_minusculas += tolower(a);
        }
        if (nombre_artistas_minusculas == nombre_artista_predefinido_minusculas){
            cout << "El artista '" << nombre << "' ya existe." << endl;
            return false;
        }
    }
    return true; // Nombre válido
}

// Función para registrar un nuevo artista 
void registrarArtista(string nombres[], GeneroMusical generos[], int votos[], int& numero_de_artistas){
    // Valida si se ha alcanzado el límite de artistas 
    if(numero_de_artistas >= MAXIMO_ARTISTAS){
        cout << "No se pueden registrar más artistas. Se alcanzó el límite de " << MAXIMO_ARTISTAS << "." << endl;
        return;
    }

    string nuevo_artista;
    cout << "Ingrese el nombre del artista que desea agregar: ";
    // Limpia el buffer de entrada antes de leer con getline (importante después de un cin >> numero)
    cin.ignore(numeric_limits<streamsize>::max(), '\n');
    getline(cin, nuevo_artista); // Lee la línea completa para nombres con espacios

    // Bucle para solicitar un nombre válido hasta que se cumpla la validación 
    while (!esNombreValido(nuevo_artista, nombres, numero_de_artistas)){
        cout << "Por favor, ingrese un nombre valido: ";
        getline(cin, nuevo_artista); // Vuelve a leer el nombre
    }

    // Solicita y valida el género musical 
    int opcion_de_genero;
    do {
        cout << "Seleccione el genero musical:" << endl;
        cout << "1. POP" << endl;
        cout << "2. CUMBIA" << endl;
        cout << "3. SALSA" << endl;
        cout << "4. ROCK" << endl;
        cout << "5. REGGAETON" << endl;
        cout << "6. OTRO" << endl;
        cout << "Ingrese el numero del genero (1-6): ";

        // Valida que la entrada sea un número y esté en el rango 1-6 
        while (!(cin >> opcion_de_genero) || opcion_de_genero < 1 || opcion_de_genero > 6) {
            cout << "Entrada invalida. Por favor, ingrese un numero entre 1 y 6: ";
            cin.clear(); // Limpia el estado de error de cin
            cin.ignore(numeric_limits<streamsize>::max(), '\n'); // Ignora el resto de la línea
        }
    } while (false); // Este do-while se ejecutará solo una vez porque la validación interna ya maneja el bucle

    // Limpia el buffer después de leer el número del género, si se va a leer otra string
    cin.ignore(numeric_limits<streamsize>::max(), '\n');

    // Asignar el nuevo artista a los arreglos 
    nombres[numero_de_artistas] = nuevo_artista;
    generos[numero_de_artistas] = static_cast<GeneroMusical>(opcion_de_genero); // Convierte int a enum
    votos[numero_de_artistas] = 0; // Inicializa los votos del nuevo artista
    numero_de_artistas++; // Incrementa el contador de artistas
    cout << "Artista '" << nuevo_artista << "' registrado exitosamente." << endl;
}

// Función para registrar votos para un artista 
void registrarVoto(const string nombres[], int votos[], int numero_de_artistas) {
    if (numero_de_artistas == 0) { // Maneja el caso de lista vacía 
        cout << "No hay artistas registrados para votar." << endl;
        return;
    }

    int opcionVoto;
    do {
        cout << "Artistas disponibles para votar:" << endl;
        for (int i = 0; i < numero_de_artistas; ++i) {
            cout << (i + 1) << ". " << nombres[i] << endl;
        }
        cout << "Ingrese el numero del artista para votar (0 para salir): ";

        // Valida la entrada del voto 
        while (!(cin >> opcionVoto) || opcionVoto < 0 || opcionVoto > numero_de_artistas) {
            cout << "Entrada invalida. Por favor, ingrese un numero entre 0 y " << numero_de_artistas << ": ";
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
        }

        if (opcionVoto >= 1 && opcionVoto <= numero_de_artistas) {
            votos[opcionVoto - 1]++; // Incrementa el voto (opcionVoto - 1 por ser índice base 0)
            cout << "Voto registrado para " << nombres[opcionVoto - 1] << "." << endl;
        } else if (opcionVoto == 0) {
            cout << "Saliendo del registro de votos." << endl; // Opción para salir del bucle 
        }
        // Limpiar el buffer si la siguiente operación no es un cin >> numero
        cin.ignore(numeric_limits<streamsize>::max(), '\n');
    } while (opcionVoto != 0); // Permite múltiples votos hasta que se ingrese 0 
}

// Función para mostrar estadísticas de votos 
void mostrarEstadisticas(const string nombres[], const GeneroMusical generos[], const int votos[], int numero_de_artistas) {
    if (numero_de_artistas == 0) { // Maneja el caso de lista vacía 
        cout << "No hay artistas registrados para mostrar estadisticas." << endl;
        return;
    }

    cout << "--- Estadisticas de Votos por Artista ---" << endl;
    for (int i = 0; i < numero_de_artistas; ++i) {
        cout << nombres[i] << ": " << votos[i] << " votos" << endl; // Muestra nombre y votos 
    }
    cout << "---------------------------------------" << endl;
}

int main() {
    // Declaración de los arreglos estáticos y el contador de artistas en main 
    string nombredeartistas[MAXIMO_ARTISTAS];
    GeneroMusical generos_de_artistas[MAXIMO_ARTISTAS];
    int votos_para_artistas[MAXIMO_ARTISTAS];
    int numero_de_artistas = 0; // Contador de artistas actual

    // Inicializa los artistas predefinidos al inicio del programa 
    inicializarArtistas(nombredeartistas, generos_de_artistas, votos_para_artistas, numero_de_artistas);

    int opcionMenu;
    do {
        // Muestra el menú principal al usuario 
        cout << "\n--- MENU PRINCIPAL ---" << endl;
        cout << "1. Registrar nuevo artista" << endl; // 
        cout << "2. Registrar voto" << endl; // 
        cout << "3. Mostrar estadisticas" << endl; // 
        cout << "4. Salir" << endl;
        cout << "Ingrese su opcion (1-4): ";

        // Valida la entrada del menú 
        while (!(cin >> opcionMenu) || opcionMenu < 1 || opcionMenu > 4) {
            cout << "Opcion invalida. Por favor, ingrese un numero entre 1 y 4: ";
            cin.clear(); // Limpia el estado de error de cin
            cin.ignore(numeric_limits<streamsize>::max(), '\n'); // Ignora el resto de la línea
        }

        // Usa un switch para manejar las opciones del menú 
        switch (opcionMenu) {
            case 1:
                registrarArtista(nombredeartistas, generos_de_artistas, votos_para_artistas, numero_de_artistas);
                break;
            case 2:
                registrarVoto(nombredeartistas, votos_para_artistas, numero_de_artistas);
                break; 
            case 3:
                mostrarEstadisticas(nombredeartistas, generos_de_artistas, votos_para_artistas, numero_de_artistas);
                break;
            case 4:
                cout << "Saliendo del programa. ¡Hasta luego!" << endl;
                break;
        }

    } while (opcionMenu != 4); // El bucle continúa hasta que el usuario elija salir

    return 0;
}